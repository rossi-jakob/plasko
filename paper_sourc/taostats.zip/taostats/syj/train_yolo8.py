# Install Ultralytics YOLO if not already installed
# !pip install ultralytics

from ultralytics import YOLO
import os

# -----------------------
# Step 1: Set up dataset
# -----------------------
# Your dataset should be structured like this:
# dataset/
#    train/
#       font1/
#          char1.png
#          char2.png
#       font2/
#          char1.png
#          ...
#    val/
#       font1/
#          ...
#       font2/
#          ...

dataset_path = "dataset"  # change to your dataset path

# -----------------------
# Step 2: Define model
# -----------------------
# You can start from a pretrained YOLOv8n or YOLOv8s model
model = YOLO("yolov8n-cls.pt")  # yolov8n pre-trained for classification

# -----------------------
# Step 3: Training
# -----------------------
# Hyperparameters for training can be adjusted as needed
model.train(
    data=dataset_path,      # Path to dataset folder
    epochs=50,              # Number of training epochs
    batch=32,               # Batch size
    imgsz=224,              # Image size
    lr0=0.001,              # Initial learning rate
    project="font_cls",     # Where to save results
    name="yolov8_font",     # Run name
    pretrained=True,        # Use pretrained weights
)

# -----------------------
# Step 4: Evaluate model
# -----------------------
results = model.val()  # Evaluate on validation set
print(results)

# -----------------------
# Step 5: Inference
# -----------------------
# Example: predict font of a new character image
img_path = "test_char.png"
pred = model.predict(img_path)
print(pred)
